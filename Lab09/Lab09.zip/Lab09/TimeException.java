public class TimeException extends Exception{
public TimeException(String string) {
		super(string);
	}
}
